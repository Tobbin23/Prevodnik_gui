print('  '.join([chr(j) for i in range(32, 128, 32) for j in range(i, i+32)]))

print(" ".join(["\\x"+hex(c)[2:] for c in "Powershell".encode()]) + "\"")
